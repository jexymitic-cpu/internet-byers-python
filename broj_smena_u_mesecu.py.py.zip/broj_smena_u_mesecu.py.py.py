ime=input("Unesite ime radnika: ")
prezime=input("Unesite prezime radnika:")
broj_smena=int(input("Unesite broj smena u mesecu:"))
if broj_smena>3:
    print("Radnik ima vise od tri smena u mesecu.") 


elif broj_smena == 3:
    print("Radnik ima tacno tri smene u mesecu.")
else:
    print("Radnik ima manje od tri smene u mesecu.")
def broj_smena_U_mesecu(Ime,prezime,broj_smena):
    return Ime + " " + prezime + ",broj smena: " + str(broj_smena)
print(broj_smena_U_mesecu(ime, prezime, broj_smena))

    

 